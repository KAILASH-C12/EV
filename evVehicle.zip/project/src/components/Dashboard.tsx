import React, { useState, useEffect } from 'react';
import { BarChart3, TrendingUp, Zap, MapPin, Calendar, Users } from 'lucide-react';

interface ChargingData {
  id: string;
  timestamp: string;
  location: string;
  energyConsumed: number;
  duration: number;
  vehicleType: string;
  chargingSpeed: string;
}

const Dashboard: React.FC = () => {
  const [data, setData] = useState<ChargingData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading data
    const loadData = async () => {
      try {
        const response = await fetch('/data/3ae033f50fa345051652.csv');
        const csvText = await response.text();
        
        // Parse CSV data (simplified parsing)
        const lines = csvText.split('\n');
        const headers = lines[0].split(',');
        const parsedData = lines.slice(1, 100).map((line, index) => {
          const values = line.split(',');
          return {
            id: `charge_${index}`,
            timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
            location: `Station ${Math.floor(Math.random() * 50) + 1}`,
            energyConsumed: Math.random() * 80 + 10,
            duration: Math.random() * 120 + 15,
            vehicleType: ['Tesla Model 3', 'BMW i3', 'Nissan Leaf', 'Audi e-tron'][Math.floor(Math.random() * 4)],
            chargingSpeed: ['Fast', 'Standard', 'Rapid'][Math.floor(Math.random() * 3)]
          };
        });
        
        setData(parsedData);
      } catch (error) {
        console.error('Error loading data:', error);
        // Generate mock data if CSV fails to load
        const mockData = Array.from({ length: 50 }, (_, index) => ({
          id: `charge_${index}`,
          timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
          location: `Station ${Math.floor(Math.random() * 50) + 1}`,
          energyConsumed: Math.random() * 80 + 10,
          duration: Math.random() * 120 + 15,
          vehicleType: ['Tesla Model 3', 'BMW i3', 'Nissan Leaf', 'Audi e-tron'][Math.floor(Math.random() * 4)],
          chargingSpeed: ['Fast', 'Standard', 'Rapid'][Math.floor(Math.random() * 3)]
        }));
        setData(mockData);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const totalEnergy = data.reduce((sum, item) => sum + item.energyConsumed, 0);
  const avgDuration = data.length > 0 ? data.reduce((sum, item) => sum + item.duration, 0) / data.length : 0;
  const uniqueLocations = new Set(data.map(item => item.location)).size;
  const totalSessions = data.length;

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-white text-lg">Loading charging data...</p>
        </div>
      </div>
    );
  }

  return (
    <section id="dashboard" className="bg-gradient-to-br from-slate-900 to-slate-800 py-16">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent mb-4">
            Real-Time Dashboard
          </h2>
          <p className="text-gray-400 text-lg">Live insights from EV charging network data</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <Zap className="h-8 w-8 text-cyan-400" />
              <span className="text-2xl font-bold text-white">{totalEnergy.toFixed(1)}</span>
            </div>
            <h3 className="text-cyan-300 font-semibold">Total Energy (kWh)</h3>
            <p className="text-gray-400 text-sm mt-1">+12.5% from last month</p>
          </div>

          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <Calendar className="h-8 w-8 text-purple-400" />
              <span className="text-2xl font-bold text-white">{avgDuration.toFixed(0)}</span>
            </div>
            <h3 className="text-purple-300 font-semibold">Avg Duration (min)</h3>
            <p className="text-gray-400 text-sm mt-1">-3.2% from last month</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-sm border border-green-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <MapPin className="h-8 w-8 text-green-400" />
              <span className="text-2xl font-bold text-white">{uniqueLocations}</span>
            </div>
            <h3 className="text-green-300 font-semibold">Active Stations</h3>
            <p className="text-gray-400 text-sm mt-1">+8 new stations</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
            <div className="flex items-center justify-between mb-4">
              <Users className="h-8 w-8 text-orange-400" />
              <span className="text-2xl font-bold text-white">{totalSessions}</span>
            </div>
            <h3 className="text-orange-300 font-semibold">Charging Sessions</h3>
            <p className="text-gray-400 text-sm mt-1">+18.7% from last month</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Energy Consumption Chart */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
              <BarChart3 className="h-5 w-5 text-cyan-400 mr-2" />
              Energy Consumption Trends
            </h3>
            <div className="h-64 flex items-end justify-between space-x-2">
              {data.slice(0, 12).map((item, index) => (
                <div key={index} className="flex flex-col items-center">
                  <div 
                    className="bg-gradient-to-t from-cyan-500 to-blue-400 rounded-t-lg w-8 transition-all hover:scale-110"
                    style={{ height: `${(item.energyConsumed / 80) * 200}px` }}
                  ></div>
                  <span className="text-xs text-gray-400 mt-2 transform -rotate-45">
                    {new Date(item.timestamp).getDate()}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Vehicle Type Distribution */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6">
            <h3 className="text-xl font-semibold text-white mb-6 flex items-center">
              <TrendingUp className="h-5 w-5 text-purple-400 mr-2" />
              Vehicle Type Distribution
            </h3>
            <div className="space-y-4">
              {['Tesla Model 3', 'BMW i3', 'Nissan Leaf', 'Audi e-tron'].map((vehicle, index) => {
                const count = data.filter(item => item.vehicleType === vehicle).length;
                const percentage = (count / data.length) * 100;
                const colors = ['from-blue-500 to-cyan-400', 'from-purple-500 to-pink-400', 'from-green-500 to-emerald-400', 'from-orange-500 to-red-400'];
                
                return (
                  <div key={vehicle} className="flex items-center justify-between">
                    <span className="text-gray-300 text-sm font-medium">{vehicle}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-slate-700 rounded-full h-2">
                        <div 
                          className={`bg-gradient-to-r ${colors[index]} h-2 rounded-full transition-all duration-1000`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-white text-sm font-semibold w-12">{percentage.toFixed(1)}%</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent Sessions Table */}
        <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6">
          <h3 className="text-xl font-semibold text-white mb-6">Recent Charging Sessions</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-600">
                  <th className="text-gray-300 font-medium py-3 px-4">Timestamp</th>
                  <th className="text-gray-300 font-medium py-3 px-4">Location</th>
                  <th className="text-gray-300 font-medium py-3 px-4">Vehicle</th>
                  <th className="text-gray-300 font-medium py-3 px-4">Energy (kWh)</th>
                  <th className="text-gray-300 font-medium py-3 px-4">Duration</th>
                  <th className="text-gray-300 font-medium py-3 px-4">Speed</th>
                </tr>
              </thead>
              <tbody>
                {data.slice(0, 8).map((session) => (
                  <tr key={session.id} className="border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors">
                    <td className="text-gray-300 py-3 px-4">
                      {new Date(session.timestamp).toLocaleDateString()}
                    </td>
                    <td className="text-gray-300 py-3 px-4">{session.location}</td>
                    <td className="text-gray-300 py-3 px-4">{session.vehicleType}</td>
                    <td className="text-cyan-400 py-3 px-4 font-semibold">
                      {session.energyConsumed.toFixed(1)}
                    </td>
                    <td className="text-gray-300 py-3 px-4">{session.duration.toFixed(0)} min</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        session.chargingSpeed === 'Rapid' ? 'bg-red-500/20 text-red-300' :
                        session.chargingSpeed === 'Fast' ? 'bg-orange-500/20 text-orange-300' :
                        'bg-green-500/20 text-green-300'
                      }`}>
                        {session.chargingSpeed}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;