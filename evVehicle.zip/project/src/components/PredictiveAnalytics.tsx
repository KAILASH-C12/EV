import React, { useState, useEffect } from 'react';
import { LineChart, BarChart3, PieChart, TrendingUp, Zap, Clock, MapPin, DollarSign, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AnalyticsData {
  timestamp: string;
  demand: number;
  efficiency: number;
  revenue: number;
  utilization: number;
}

interface Forecast {
  period: string;
  demand: number;
  confidence: number;
  efficiency: number;
  revenue: number;
}

const PredictiveAnalytics: React.FC = () => {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData[]>([]);
  const [forecasts, setForecasts] = useState<Forecast[]>([]);
  const [selectedMetric, setSelectedMetric] = useState<'demand' | 'efficiency' | 'revenue' | 'utilization'>('demand');
  const [timeRange, setTimeRange] = useState<'1h' | '24h' | '7d' | '30d'>('24h');

  useEffect(() => {
    // Generate realistic time-series data
    const generateAnalyticsData = () => {
      const data: AnalyticsData[] = [];
      const now = new Date();
      
      for (let i = 23; i >= 0; i--) {
        const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
        const hour = timestamp.getHours();
        
        // Simulate realistic patterns
        const baseDemand = 100 + Math.sin((hour - 6) * Math.PI / 12) * 50;
        const peakMultiplier = (hour >= 17 && hour <= 20) ? 1.8 : 1;
        
        data.push({
          timestamp: timestamp.toISOString(),
          demand: Math.max(20, baseDemand * peakMultiplier + (Math.random() - 0.5) * 30),
          efficiency: 85 + Math.sin(hour * Math.PI / 12) * 10 + (Math.random() - 0.5) * 8,
          revenue: (baseDemand * peakMultiplier * 0.35) + (Math.random() - 0.5) * 20,
          utilization: Math.min(95, Math.max(15, baseDemand * peakMultiplier * 0.6 + (Math.random() - 0.5) * 20))
        });
      }
      
      setAnalyticsData(data);
    };

    const generateForecasts = () => {
      const periods = ['Next Hour', '6 Hours', '12 Hours', '24 Hours', '3 Days', '7 Days'];
      const forecastData: Forecast[] = periods.map((period, index) => {
        const baseValue = 120 + index * 15;
        return {
          period,
          demand: baseValue + (Math.random() - 0.5) * 40,
          confidence: 95 - index * 3 + (Math.random() - 0.5) * 10,
          efficiency: 88 + (Math.random() - 0.5) * 12,
          revenue: (baseValue * 0.4) + (Math.random() - 0.5) * 25
        };
      });
      
      setForecasts(forecastData);
    };

    generateAnalyticsData();
    generateForecasts();

    const interval = setInterval(() => {
      generateAnalyticsData();
      generateForecasts();
    }, 10000);

    return () => clearInterval(interval);
  }, [timeRange]);

  const getMetricValue = (data: AnalyticsData, metric: string) => {
    switch (metric) {
      case 'demand': return data.demand;
      case 'efficiency': return data.efficiency;
      case 'revenue': return data.revenue;
      case 'utilization': return data.utilization;
      default: return data.demand;
    }
  };

  const getMetricColor = (metric: string) => {
    switch (metric) {
      case 'demand': return 'from-blue-500 to-cyan-400';
      case 'efficiency': return 'from-green-500 to-emerald-400';
      case 'revenue': return 'from-purple-500 to-pink-400';
      case 'utilization': return 'from-orange-500 to-red-400';
      default: return 'from-blue-500 to-cyan-400';
    }
  };

  const getMetricIcon = (metric: string) => {
    switch (metric) {
      case 'demand': return Zap;
      case 'efficiency': return TrendingUp;
      case 'revenue': return DollarSign;
      case 'utilization': return Clock;
      default: return Zap;
    }
  };

  const getMetricUnit = (metric: string) => {
    switch (metric) {
      case 'demand': return 'kWh';
      case 'efficiency': return '%';
      case 'revenue': return '$';
      case 'utilization': return '%';
      default: return '';
    }
  };

  const maxValue = Math.max(...analyticsData.map(d => getMetricValue(d, selectedMetric)));
  const minValue = Math.min(...analyticsData.map(d => getMetricValue(d, selectedMetric)));
  const avgValue = analyticsData.reduce((sum, d) => sum + getMetricValue(d, selectedMetric), 0) / analyticsData.length;

  return (
    <section className="bg-gradient-to-br from-slate-800 via-indigo-900 to-slate-800 py-16">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-5xl font-bold bg-gradient-to-r from-indigo-400 via-purple-500 to-pink-500 bg-clip-text text-transparent mb-4">
            Predictive Analytics Engine
          </h2>
          <p className="text-gray-300 text-xl max-w-4xl mx-auto">
            Advanced machine learning algorithms analyze patterns, predict trends, and optimize charging station performance in real-time
          </p>
        </div>

        {/* Controls */}
        <div className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 backdrop-blur-xl border border-slate-600/50 rounded-2xl p-6 mb-8">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="flex flex-wrap gap-3">
              {(['demand', 'efficiency', 'revenue', 'utilization'] as const).map((metric) => {
                const IconComponent = getMetricIcon(metric);
                return (
                  <button
                    key={metric}
                    onClick={() => setSelectedMetric(metric)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                      selectedMetric === metric
                        ? `bg-gradient-to-r ${getMetricColor(metric)} text-white shadow-lg scale-105`
                        : 'bg-slate-700/50 text-gray-300 hover:bg-slate-600/50'
                    }`}
                  >
                    <IconComponent className="h-4 w-4" />
                    <span className="capitalize">{metric}</span>
                  </button>
                );
              })}
            </div>
            
            <div className="flex items-center space-x-4">
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as any)}
                className="bg-slate-700/80 border border-slate-600 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-indigo-400"
              >
                <option value="1h">Last Hour</option>
                <option value="24h">Last 24 Hours</option>
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days</option>
              </select>
              
              <div className="flex items-center space-x-2 text-gray-300">
                <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Live Updates</span>
              </div>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className={`bg-gradient-to-br ${getMetricColor(selectedMetric)}/20 backdrop-blur-sm border border-gray-600/30 rounded-2xl p-6`}>
            <div className="flex items-center justify-between mb-4">
              <div className={`p-3 rounded-xl bg-gradient-to-r ${getMetricColor(selectedMetric)}`}>
                {React.createElement(getMetricIcon(selectedMetric), { className: "h-6 w-6 text-white" })}
              </div>
              <TrendingUp className="h-5 w-5 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-white mb-1">
              {avgValue.toFixed(1)} {getMetricUnit(selectedMetric)}
            </div>
            <div className="text-gray-300 text-sm">Average {selectedMetric}</div>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-sm border border-green-500/30 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-400">
                <TrendingUp className="h-6 w-6 text-white" />
              </div>
              <CheckCircle2 className="h-5 w-5 text-green-400" />
            </div>
            <div className="text-3xl font-bold text-white mb-1">
              {maxValue.toFixed(1)} {getMetricUnit(selectedMetric)}
            </div>
            <div className="text-gray-300 text-sm">Peak {selectedMetric}</div>
          </div>

          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-purple-500/30 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 rounded-xl bg-gradient-to-r from-purple-500 to-pink-400">
                <BarChart3 className="h-6 w-6 text-white" />
              </div>
              <AlertCircle className="h-5 w-5 text-purple-400" />
            </div>
            <div className="text-3xl font-bold text-white mb-1">
              {((maxValue - minValue) / avgValue * 100).toFixed(1)}%
            </div>
            <div className="text-gray-300 text-sm">Volatility Index</div>
          </div>
        </div>

        {/* Main Chart and Forecasts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Time Series Chart */}
          <div className="lg:col-span-2 bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white flex items-center">
                <LineChart className="h-6 w-6 text-indigo-400 mr-3" />
                {selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)} Trends
              </h3>
              <div className="text-sm text-gray-400">
                Last 24 hours
              </div>
            </div>
            
            <div className="h-80 flex items-end justify-between space-x-1">
              {analyticsData.map((data, index) => {
                const value = getMetricValue(data, selectedMetric);
                const height = ((value - minValue) / (maxValue - minValue)) * 280 + 20;
                const time = new Date(data.timestamp).getHours();
                
                return (
                  <div key={index} className="flex flex-col items-center group relative">
                    <div 
                      className={`bg-gradient-to-t ${getMetricColor(selectedMetric)} rounded-t-lg w-4 transition-all hover:scale-110 relative`}
                      style={{ height: `${height}px` }}
                    >
                      <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap z-10">
                        <div className="font-semibold">{value.toFixed(1)} {getMetricUnit(selectedMetric)}</div>
                        <div className="text-gray-400">{time}:00</div>
                      </div>
                    </div>
                    <span className="text-xs text-gray-400 mt-2">
                      {time}h
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Forecasts */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
              <PieChart className="h-6 w-6 text-purple-400 mr-3" />
              ML Forecasts
            </h3>
            
            <div className="space-y-4">
              {forecasts.map((forecast, index) => (
                <div key={index} className="bg-slate-700/30 rounded-xl p-4 hover:bg-slate-700/50 transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white font-medium">{forecast.period}</span>
                    <span className="text-xs text-gray-400">
                      {forecast.confidence.toFixed(0)}% confidence
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <div className="text-gray-400">Demand</div>
                      <div className="text-cyan-400 font-semibold">
                        {forecast.demand.toFixed(0)} kWh
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400">Efficiency</div>
                      <div className="text-green-400 font-semibold">
                        {forecast.efficiency.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-3">
                    <div className="flex justify-between text-xs text-gray-400 mb-1">
                      <span>Confidence</span>
                      <span>{forecast.confidence.toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-slate-600 rounded-full h-1.5">
                      <div 
                        className="bg-gradient-to-r from-indigo-500 to-purple-400 h-1.5 rounded-full transition-all duration-1000"
                        style={{ width: `${forecast.confidence}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Advanced Insights */}
        <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <MapPin className="h-6 w-6 text-cyan-400 mr-3" />
            AI-Generated Insights
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-500/30 rounded-xl p-6">
              <div className="flex items-center mb-3">
                <Zap className="h-5 w-5 text-cyan-400 mr-2" />
                <span className="text-cyan-300 font-semibold">Peak Demand Alert</span>
              </div>
              <p className="text-gray-300 text-sm mb-3">
                ML models predict 340% demand spike at 6:30 PM today. Recommend activating backup systems.
              </p>
              <div className="text-xs text-cyan-400 font-medium">Confidence: 94.2%</div>
            </div>

            <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-6">
              <div className="flex items-center mb-3">
                <TrendingUp className="h-5 w-5 text-green-400 mr-2" />
                <span className="text-green-300 font-semibold">Efficiency Optimization</span>
              </div>
              <p className="text-gray-300 text-sm mb-3">
                Load balancing algorithm suggests 18% efficiency improvement through smart routing.
              </p>
              <div className="text-xs text-green-400 font-medium">Potential Savings: $2,340/month</div>
            </div>

            <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-xl p-6">
              <div className="flex items-center mb-3">
                <DollarSign className="h-5 w-5 text-purple-400 mr-2" />
                <span className="text-purple-300 font-semibold">Revenue Forecast</span>
              </div>
              <p className="text-gray-300 text-sm mb-3">
                Dynamic pricing model predicts 23% revenue increase with optimized rate adjustments.
              </p>
              <div className="text-xs text-purple-400 font-medium">Projected: +$15,670 this month</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PredictiveAnalytics;