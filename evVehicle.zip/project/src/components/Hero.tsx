import React from 'react';
import { TrendingUp, Zap, MapPin, Clock } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="relative bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white py-20 overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20"></div>
      <div className="absolute inset-0">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative container mx-auto px-6">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-600 bg-clip-text text-transparent">
            EV Charging Demand Intelligence
          </h1>
          <p className="text-xl md:text-2xl text-gray-300 mb-8 leading-relaxed">
            Harness the power of machine learning to predict, analyze, and optimize 
            electric vehicle charging patterns with unprecedented accuracy
          </p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
            <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
              <TrendingUp className="h-8 w-8 text-cyan-400 mx-auto mb-3" />
              <h3 className="font-semibold text-cyan-300">Demand Forecasting</h3>
              <p className="text-sm text-gray-400 mt-2">AI-powered predictions</p>
            </div>
            
            <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
              <Zap className="h-8 w-8 text-purple-400 mx-auto mb-3" />
              <h3 className="font-semibold text-purple-300">Energy Analytics</h3>
              <p className="text-sm text-gray-400 mt-2">Real-time insights</p>
            </div>
            
            <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-sm border border-green-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
              <MapPin className="h-8 w-8 text-green-400 mx-auto mb-3" />
              <h3 className="font-semibold text-green-300">Location Intelligence</h3>
              <p className="text-sm text-gray-400 mt-2">Spatial analysis</p>
            </div>
            
            <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6 hover:scale-105 transition-transform">
              <Clock className="h-8 w-8 text-orange-400 mx-auto mb-3" />
              <h3 className="font-semibold text-orange-300">Time Series</h3>
              <p className="text-sm text-gray-400 mt-2">Temporal patterns</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;