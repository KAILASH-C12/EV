import React, { useState, useEffect } from 'react';
import { Lightbulb, Target, Zap, TrendingUp, AlertTriangle, CheckCircle, Clock, DollarSign, Settings, Cpu } from 'lucide-react';

interface Recommendation {
  id: string;
  type: 'efficiency' | 'maintenance' | 'revenue' | 'demand';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  impact: string;
  confidence: number;
  timeframe: string;
  savings: number;
  status: 'new' | 'in-progress' | 'completed';
}

interface OptimizationMetric {
  name: string;
  current: number;
  optimized: number;
  improvement: number;
  unit: string;
  color: string;
}

const SmartRecommendations: React.FC = () => {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [metrics, setMetrics] = useState<OptimizationMetric[]>([]);
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'efficiency' | 'maintenance' | 'revenue' | 'demand'>('all');
  const [isOptimizing, setIsOptimizing] = useState(false);

  useEffect(() => {
    const generateRecommendations = () => {
      const recommendationData: Recommendation[] = [
        {
          id: '1',
          type: 'efficiency',
          priority: 'high',
          title: 'Implement Smart Load Balancing',
          description: 'Deploy AI-driven load balancing across stations A, C, and F to optimize energy distribution and reduce peak load stress.',
          impact: 'Reduce energy waste by 23% and improve overall network efficiency',
          confidence: 94.2,
          timeframe: '2-3 weeks',
          savings: 2340,
          status: 'new'
        },
        {
          id: '2',
          type: 'maintenance',
          priority: 'high',
          title: 'Preventive Maintenance - Station H',
          description: 'ML analysis indicates degrading performance patterns. Schedule maintenance to prevent potential 48-hour downtime.',
          impact: 'Prevent $8,500 in lost revenue and maintain 99.2% uptime',
          confidence: 91.7,
          timeframe: '3-5 days',
          savings: 8500,
          status: 'new'
        },
        {
          id: '3',
          type: 'revenue',
          priority: 'medium',
          title: 'Dynamic Pricing Optimization',
          description: 'Implement ML-based dynamic pricing during peak hours (5-8 PM) to maximize revenue while maintaining customer satisfaction.',
          impact: 'Increase revenue by 18% during peak periods',
          confidence: 87.3,
          timeframe: '1-2 weeks',
          savings: 4200,
          status: 'in-progress'
        },
        {
          id: '4',
          type: 'demand',
          priority: 'high',
          title: 'Capacity Expansion - Downtown Zone',
          description: 'Demand forecasting shows 340% increase expected. Add 3 fast-charging stations to meet growing demand.',
          impact: 'Capture additional $12,000 monthly revenue and reduce wait times',
          confidence: 96.1,
          timeframe: '4-6 weeks',
          savings: 12000,
          status: 'new'
        },
        {
          id: '5',
          type: 'efficiency',
          priority: 'medium',
          title: 'Energy Storage Integration',
          description: 'Install battery storage systems to store off-peak energy and reduce grid dependency during high-demand periods.',
          impact: 'Reduce energy costs by 15% and improve grid stability',
          confidence: 89.4,
          timeframe: '6-8 weeks',
          savings: 3600,
          status: 'new'
        },
        {
          id: '6',
          type: 'maintenance',
          priority: 'low',
          title: 'Predictive Component Replacement',
          description: 'Replace charging cables at stations B and E based on wear pattern analysis before failure occurs.',
          impact: 'Prevent unexpected downtime and maintain service quality',
          confidence: 82.6,
          timeframe: '1-2 weeks',
          savings: 1200,
          status: 'completed'
        }
      ];
      
      setRecommendations(recommendationData);
    };

    const generateMetrics = () => {
      const metricsData: OptimizationMetric[] = [
        {
          name: 'Network Efficiency',
          current: 78.4,
          optimized: 94.2,
          improvement: 15.8,
          unit: '%',
          color: 'from-green-500 to-emerald-400'
        },
        {
          name: 'Average Uptime',
          current: 94.7,
          optimized: 99.2,
          improvement: 4.5,
          unit: '%',
          color: 'from-blue-500 to-cyan-400'
        },
        {
          name: 'Energy Cost',
          current: 0.18,
          optimized: 0.14,
          improvement: 22.2,
          unit: '$/kWh',
          color: 'from-purple-500 to-pink-400'
        },
        {
          name: 'Customer Wait Time',
          current: 8.3,
          optimized: 3.1,
          improvement: 62.7,
          unit: 'min',
          color: 'from-orange-500 to-red-400'
        }
      ];
      
      setMetrics(metricsData);
    };

    generateRecommendations();
    generateMetrics();
  }, []);

  const filteredRecommendations = selectedFilter === 'all' 
    ? recommendations 
    : recommendations.filter(rec => rec.type === selectedFilter);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'from-red-500 to-pink-400';
      case 'medium': return 'from-yellow-500 to-orange-400';
      case 'low': return 'from-green-500 to-emerald-400';
      default: return 'from-gray-500 to-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'efficiency': return Zap;
      case 'maintenance': return Settings;
      case 'revenue': return DollarSign;
      case 'demand': return TrendingUp;
      default: return Lightbulb;
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'new': return AlertTriangle;
      case 'in-progress': return Clock;
      case 'completed': return CheckCircle;
      default: return AlertTriangle;
    }
  };

  const runOptimization = async () => {
    setIsOptimizing(true);
    await new Promise(resolve => setTimeout(resolve, 4000));
    setIsOptimizing(false);
  };

  return (
    <section className="bg-gradient-to-br from-indigo-900 via-purple-900 to-slate-900 py-16">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-full mr-4">
              <Lightbulb className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-5xl font-bold bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 bg-clip-text text-transparent">
              Smart Recommendations Engine
            </h2>
          </div>
          <p className="text-gray-300 text-xl max-w-4xl mx-auto">
            AI-powered recommendations to optimize your charging network performance, reduce costs, and maximize revenue through intelligent automation
          </p>
        </div>

        {/* Optimization Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {metrics.map((metric, index) => (
            <div key={index} className={`bg-gradient-to-br ${metric.color}/20 backdrop-blur-sm border border-gray-600/30 rounded-2xl p-6 hover:scale-105 transition-all duration-300`}>
              <div className="flex items-center justify-between mb-4">
                <Target className={`h-8 w-8 bg-gradient-to-r ${metric.color} bg-clip-text text-transparent`} />
                <div className="text-right">
                  <div className="text-2xl font-bold text-white">
                    +{metric.improvement.toFixed(1)}%
                  </div>
                  <div className="text-xs text-gray-400">Improvement</div>
                </div>
              </div>
              <h3 className="text-white font-semibold mb-2">{metric.name}</h3>
              <div className="flex justify-between text-sm text-gray-400 mb-2">
                <span>Current: {metric.current}{metric.unit}</span>
                <span>Target: {metric.optimized}{metric.unit}</span>
              </div>
              <div className="w-full bg-slate-700 rounded-full h-2">
                <div 
                  className={`bg-gradient-to-r ${metric.color} h-2 rounded-full transition-all duration-1000`}
                  style={{ width: `${(metric.improvement / 100) * 100}%` }}
                ></div>
              </div>
            </div>
          ))}
        </div>

        {/* Control Panel */}
        <div className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 backdrop-blur-xl border border-slate-600/50 rounded-2xl p-6 mb-8">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
            <div className="flex flex-wrap gap-3">
              {(['all', 'efficiency', 'maintenance', 'revenue', 'demand'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-4 py-2 rounded-xl font-medium transition-all duration-300 ${
                    selectedFilter === filter
                      ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-white shadow-lg scale-105'
                      : 'bg-slate-700/50 text-gray-300 hover:bg-slate-600/50'
                  }`}
                >
                  {filter.charAt(0).toUpperCase() + filter.slice(1)}
                </button>
              ))}
            </div>
            
            <button
              onClick={runOptimization}
              disabled={isOptimizing}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 disabled:opacity-50 text-white font-semibold px-6 py-3 rounded-xl transition-all duration-300 flex items-center"
            >
              {isOptimizing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Optimizing Network...
                </>
              ) : (
                <>
                  <Cpu className="h-5 w-5 mr-2" />
                  Run Full Optimization
                </>
              )}
            </button>
          </div>
        </div>

        {/* Recommendations Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {filteredRecommendations.map((recommendation) => {
            const TypeIcon = getTypeIcon(recommendation.type);
            const StatusIcon = getStatusIcon(recommendation.status);
            
            return (
              <div key={recommendation.id} className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-6 hover:scale-105 transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className={`p-3 rounded-xl bg-gradient-to-r ${getPriorityColor(recommendation.priority)}`}>
                      <TypeIcon className="h-6 w-6 text-white" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-white">{recommendation.title}</h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          recommendation.priority === 'high' ? 'bg-red-500/20 text-red-300' :
                          recommendation.priority === 'medium' ? 'bg-yellow-500/20 text-yellow-300' :
                          'bg-green-500/20 text-green-300'
                        }`}>
                          {recommendation.priority.toUpperCase()} PRIORITY
                        </span>
                        <span className="text-gray-400 text-xs">{recommendation.type.toUpperCase()}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <StatusIcon className={`h-5 w-5 ${
                      recommendation.status === 'completed' ? 'text-green-400' :
                      recommendation.status === 'in-progress' ? 'text-yellow-400' :
                      'text-red-400'
                    }`} />
                  </div>
                </div>

                <p className="text-gray-300 mb-4">{recommendation.description}</p>
                
                <div className="bg-slate-700/30 rounded-xl p-4 mb-4">
                  <div className="flex items-center mb-2">
                    <Target className="h-4 w-4 text-cyan-400 mr-2" />
                    <span className="text-cyan-300 font-medium">Expected Impact</span>
                  </div>
                  <p className="text-gray-300 text-sm">{recommendation.impact}</p>
                </div>

                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-gray-400 mb-1">Confidence</div>
                    <div className="text-white font-semibold">{recommendation.confidence}%</div>
                    <div className="w-full bg-slate-600 rounded-full h-1 mt-1">
                      <div 
                        className="bg-gradient-to-r from-green-500 to-emerald-400 h-1 rounded-full"
                        style={{ width: `${recommendation.confidence}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="text-gray-400 mb-1">Timeframe</div>
                    <div className="text-white font-semibold">{recommendation.timeframe}</div>
                  </div>
                  
                  <div>
                    <div className="text-gray-400 mb-1">Potential Savings</div>
                    <div className="text-green-400 font-semibold">${recommendation.savings.toLocaleString()}</div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-slate-600/30">
                  <button className={`w-full py-2 px-4 rounded-xl font-medium transition-all ${
                    recommendation.status === 'completed' 
                      ? 'bg-green-500/20 text-green-300 cursor-not-allowed'
                      : recommendation.status === 'in-progress'
                      ? 'bg-yellow-500/20 text-yellow-300 cursor-not-allowed'
                      : 'bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 text-white'
                  }`}>
                    {recommendation.status === 'completed' ? 'Completed' :
                     recommendation.status === 'in-progress' ? 'In Progress' :
                     'Implement Recommendation'}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Summary Stats */}
        <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <TrendingUp className="h-6 w-6 text-yellow-400 mr-3" />
            Optimization Impact Summary
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-cyan-400 mb-2">
                ${recommendations.reduce((sum, rec) => sum + rec.savings, 0).toLocaleString()}
              </div>
              <div className="text-gray-300">Total Potential Savings</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-green-400 mb-2">
                {recommendations.filter(rec => rec.priority === 'high').length}
              </div>
              <div className="text-gray-300">High Priority Items</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">
                {(recommendations.reduce((sum, rec) => sum + rec.confidence, 0) / recommendations.length).toFixed(1)}%
              </div>
              <div className="text-gray-300">Average Confidence</div>
            </div>
            
            <div className="text-center">
              <div className="text-3xl font-bold text-orange-400 mb-2">
                {recommendations.filter(rec => rec.status === 'completed').length}/{recommendations.length}
              </div>
              <div className="text-gray-300">Completed Actions</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SmartRecommendations;