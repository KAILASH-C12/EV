import React, { useState } from 'react';
import { Database, Search, Filter, Download, Eye, BarChart3 } from 'lucide-react';

const DataExplorer: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [viewMode, setViewMode] = useState('table');

  const sampleData = [
    { id: 1, timestamp: '2024-01-15 14:30', station: 'Downtown-01', vehicle: 'Tesla Model 3', energy: 45.2, duration: 65, status: 'Completed' },
    { id: 2, timestamp: '2024-01-15 15:45', station: 'Mall-03', vehicle: 'BMW i3', energy: 32.8, duration: 48, status: 'Completed' },
    { id: 3, timestamp: '2024-01-15 16:20', station: 'Highway-07', vehicle: 'Audi e-tron', energy: 67.5, duration: 82, status: 'In Progress' },
    { id: 4, timestamp: '2024-01-15 17:10', station: 'Office-12', vehicle: 'Nissan Leaf', energy: 28.9, duration: 42, status: 'Completed' },
    { id: 5, timestamp: '2024-01-15 18:30', station: 'Residential-05', vehicle: 'Tesla Model Y', energy: 52.3, duration: 71, status: 'Completed' },
  ];

  const dataStats = {
    totalRecords: 15847,
    avgEnergy: 42.7,
    avgDuration: 58.3,
    completionRate: 94.2
  };

  return (
    <section id="data" className="bg-gradient-to-br from-slate-900 to-slate-800 py-16">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-4">
            Data Explorer
          </h2>
          <p className="text-gray-400 text-lg">Explore and analyze EV charging datasets</p>
        </div>

        {/* Data Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500/20 to-cyan-500/20 backdrop-blur-sm border border-blue-500/30 rounded-xl p-6">
            <Database className="h-8 w-8 text-cyan-400 mb-3" />
            <div className="text-2xl font-bold text-white">{dataStats.totalRecords.toLocaleString()}</div>
            <div className="text-cyan-300 font-medium">Total Records</div>
          </div>
          
          <div className="bg-gradient-to-br from-purple-500/20 to-pink-500/20 backdrop-blur-sm border border-purple-500/30 rounded-xl p-6">
            <BarChart3 className="h-8 w-8 text-purple-400 mb-3" />
            <div className="text-2xl font-bold text-white">{dataStats.avgEnergy} kWh</div>
            <div className="text-purple-300 font-medium">Avg Energy</div>
          </div>
          
          <div className="bg-gradient-to-br from-green-500/20 to-emerald-500/20 backdrop-blur-sm border border-green-500/30 rounded-xl p-6">
            <Eye className="h-8 w-8 text-green-400 mb-3" />
            <div className="text-2xl font-bold text-white">{dataStats.avgDuration} min</div>
            <div className="text-green-300 font-medium">Avg Duration</div>
          </div>
          
          <div className="bg-gradient-to-br from-orange-500/20 to-red-500/20 backdrop-blur-sm border border-orange-500/30 rounded-xl p-6">
            <Download className="h-8 w-8 text-orange-400 mb-3" />
            <div className="text-2xl font-bold text-white">{dataStats.completionRate}%</div>
            <div className="text-orange-300 font-medium">Success Rate</div>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex flex-col md:flex-row gap-4 flex-1">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search charging sessions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
                />
              </div>
              
              <div className="relative">
                <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <select
                  value={selectedFilter}
                  onChange={(e) => setSelectedFilter(e.target.value)}
                  className="pl-10 pr-8 py-2 bg-slate-700 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-cyan-400 focus:border-transparent"
                >
                  <option value="all">All Sessions</option>
                  <option value="completed">Completed</option>
                  <option value="in-progress">In Progress</option>
                  <option value="tesla">Tesla Vehicles</option>
                  <option value="high-energy">{"High Energy (>50kWh)"}</option>
                </select>
              </div>
            </div>
            
            <div className="flex gap-2">
              <button
                onClick={() => setViewMode('table')}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  viewMode === 'table' 
                    ? 'bg-cyan-500 text-white' 
                    : 'bg-slate-700 text-gray-300 hover:bg-slate-600'
                }`}
              >
                Table View
              </button>
              <button
                onClick={() => setViewMode('chart')}
                className={`px-4 py-2 rounded-lg font-medium transition-all ${
                  viewMode === 'chart' 
                    ? 'bg-cyan-500 text-white' 
                    : 'bg-slate-700 text-gray-300 hover:bg-slate-600'
                }`}
              >
                Chart View
              </button>
              <button className="px-4 py-2 bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white rounded-lg font-medium transition-all flex items-center">
                <Download className="h-4 w-4 mr-2" />
                Export
              </button>
            </div>
          </div>
        </div>

        {/* Data Display */}
        {viewMode === 'table' ? (
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-slate-700/50">
                  <tr>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">ID</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Timestamp</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Station</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Vehicle</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Energy (kWh)</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Duration (min)</th>
                    <th className="text-left text-gray-300 font-medium py-4 px-6">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {sampleData.map((row, index) => (
                    <tr key={row.id} className={`border-b border-slate-700/50 hover:bg-slate-700/30 transition-colors ${index % 2 === 0 ? 'bg-slate-800/20' : ''}`}>
                      <td className="py-4 px-6 text-cyan-400 font-medium">#{row.id}</td>
                      <td className="py-4 px-6 text-gray-300">{row.timestamp}</td>
                      <td className="py-4 px-6 text-gray-300">{row.station}</td>
                      <td className="py-4 px-6 text-gray-300">{row.vehicle}</td>
                      <td className="py-4 px-6 text-cyan-400 font-semibold">{row.energy}</td>
                      <td className="py-4 px-6 text-gray-300">{row.duration}</td>
                      <td className="py-4 px-6">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                          row.status === 'Completed' 
                            ? 'bg-green-500/20 text-green-300' 
                            : 'bg-orange-500/20 text-orange-300'
                        }`}>
                          {row.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="bg-slate-700/30 px-6 py-4 flex items-center justify-between">
              <span className="text-gray-400 text-sm">Showing 5 of {dataStats.totalRecords.toLocaleString()} records</span>
              <div className="flex gap-2">
                <button className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white rounded text-sm transition-colors">Previous</button>
                <button className="px-3 py-1 bg-cyan-500 text-white rounded text-sm">1</button>
                <button className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white rounded text-sm transition-colors">2</button>
                <button className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white rounded text-sm transition-colors">3</button>
                <button className="px-3 py-1 bg-slate-600 hover:bg-slate-500 text-white rounded text-sm transition-colors">Next</button>
              </div>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-6">Energy Distribution</h3>
              <div className="h-64 flex items-end justify-between space-x-2">
                {sampleData.map((item, index) => (
                  <div key={index} className="flex flex-col items-center">
                    <div 
                      className="bg-gradient-to-t from-cyan-500 to-blue-400 rounded-t-lg w-12 transition-all hover:scale-110"
                      style={{ height: `${(item.energy / 70) * 200}px` }}
                    ></div>
                    <span className="text-xs text-gray-400 mt-2 transform -rotate-45">
                      {item.station.split('-')[0]}
                    </span>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-6">
              <h3 className="text-xl font-semibold text-white mb-6">Duration Analysis</h3>
              <div className="space-y-4">
                {sampleData.map((item, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <span className="text-gray-300 text-sm font-medium">{item.vehicle}</span>
                    <div className="flex items-center space-x-3">
                      <div className="w-32 bg-slate-700 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-pink-400 h-2 rounded-full transition-all duration-1000"
                          style={{ width: `${(item.duration / 100) * 100}%` }}
                        ></div>
                      </div>
                      <span className="text-white text-sm font-semibold w-12">{item.duration}m</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default DataExplorer;