import React, { useState } from 'react';
import { Brain, TrendingUp, Target, Zap, Calendar, MapPin, BarChart3 } from 'lucide-react';

const MLModels: React.FC = () => {
  const [selectedModel, setSelectedModel] = useState('demand-forecasting');
  const [prediction, setPrediction] = useState<number | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const models = [
    {
      id: 'demand-forecasting',
      name: 'Demand Forecasting',
      icon: TrendingUp,
      description: 'Predict future charging demand using time series analysis',
      accuracy: 94.2,
      color: 'from-blue-500 to-cyan-400'
    },
    {
      id: 'energy-optimization',
      name: 'Energy Optimization',
      icon: Zap,
      description: 'Optimize energy distribution across charging stations',
      accuracy: 91.8,
      color: 'from-purple-500 to-pink-400'
    },
    {
      id: 'location-analysis',
      name: 'Location Intelligence',
      icon: MapPin,
      description: 'Identify optimal locations for new charging stations',
      accuracy: 89.5,
      color: 'from-green-500 to-emerald-400'
    },
    {
      id: 'peak-prediction',
      name: 'Peak Time Prediction',
      icon: Calendar,
      description: 'Predict peak usage hours and seasonal patterns',
      accuracy: 92.7,
      color: 'from-orange-500 to-red-400'
    }
  ];

  const handlePrediction = async () => {
    setIsLoading(true);
    // Simulate ML model prediction
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockPredictions = {
      'demand-forecasting': Math.random() * 500 + 200,
      'energy-optimization': Math.random() * 100 + 50,
      'location-analysis': Math.random() * 10 + 5,
      'peak-prediction': Math.random() * 24
    };
    
    setPrediction(mockPredictions[selectedModel as keyof typeof mockPredictions]);
    setIsLoading(false);
  };

  const selectedModelData = models.find(m => m.id === selectedModel);

  return (
    <section id="analytics" className="bg-gradient-to-br from-slate-800 to-slate-900 py-16">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-4">
            Machine Learning Models
          </h2>
          <p className="text-gray-400 text-lg">Advanced AI algorithms for EV charging insights</p>
        </div>

        {/* Model Selection Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {models.map((model) => {
            const IconComponent = model.icon;
            return (
              <div
                key={model.id}
                onClick={() => setSelectedModel(model.id)}
                className={`cursor-pointer transition-all duration-300 hover:scale-105 ${
                  selectedModel === model.id 
                    ? 'ring-2 ring-cyan-400 scale-105' 
                    : 'hover:ring-1 hover:ring-gray-500'
                }`}
              >
                <div className={`bg-gradient-to-br ${model.color}/20 backdrop-blur-sm border border-gray-600/30 rounded-xl p-6`}>
                  <div className="flex items-center justify-between mb-4">
                    <IconComponent className={`h-8 w-8 bg-gradient-to-r ${model.color} bg-clip-text text-transparent`} />
                    <div className="text-right">
                      <div className="text-2xl font-bold text-white">{model.accuracy}%</div>
                      <div className="text-xs text-gray-400">Accuracy</div>
                    </div>
                  </div>
                  <h3 className="text-white font-semibold mb-2">{model.name}</h3>
                  <p className="text-gray-400 text-sm">{model.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Model Details and Prediction */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Model Details */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-8">
            <div className="flex items-center mb-6">
              <Brain className="h-8 w-8 text-cyan-400 mr-3" />
              <h3 className="text-2xl font-bold text-white">Model Details</h3>
            </div>
            
            {selectedModelData && (
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-white mb-2">{selectedModelData.name}</h4>
                  <p className="text-gray-400">{selectedModelData.description}</p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-700/50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-cyan-400">{selectedModelData.accuracy}%</div>
                    <div className="text-sm text-gray-400">Model Accuracy</div>
                  </div>
                  <div className="bg-slate-700/50 rounded-lg p-4">
                    <div className="text-2xl font-bold text-purple-400">98.5%</div>
                    <div className="text-sm text-gray-400">Data Quality</div>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <h5 className="text-white font-medium">Key Features:</h5>
                  <ul className="space-y-2 text-gray-400">
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-cyan-400 rounded-full mr-3"></div>
                      Real-time data processing
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-purple-400 rounded-full mr-3"></div>
                      Advanced neural networks
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-green-400 rounded-full mr-3"></div>
                      Continuous learning
                    </li>
                    <li className="flex items-center">
                      <div className="w-2 h-2 bg-orange-400 rounded-full mr-3"></div>
                      Multi-variable analysis
                    </li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Prediction Interface */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-8">
            <div className="flex items-center mb-6">
              <Target className="h-8 w-8 text-purple-400 mr-3" />
              <h3 className="text-2xl font-bold text-white">Live Prediction</h3>
            </div>
            
            <div className="space-y-6">
              <div>
                <label className="block text-gray-300 font-medium mb-2">Selected Model</label>
                <div className={`bg-gradient-to-r ${selectedModelData?.color}/20 border border-gray-600 rounded-lg p-3`}>
                  <span className="text-white font-medium">{selectedModelData?.name}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-300 font-medium mb-2">Time Horizon</label>
                  <select className="w-full bg-slate-700 border border-gray-600 rounded-lg p-3 text-white">
                    <option>Next Hour</option>
                    <option>Next Day</option>
                    <option>Next Week</option>
                    <option>Next Month</option>
                  </select>
                </div>
                <div>
                  <label className="block text-gray-300 font-medium mb-2">Location</label>
                  <select className="w-full bg-slate-700 border border-gray-600 rounded-lg p-3 text-white">
                    <option>All Stations</option>
                    <option>Downtown</option>
                    <option>Suburbs</option>
                    <option>Highway</option>
                  </select>
                </div>
              </div>
              
              <button
                onClick={handlePrediction}
                disabled={isLoading}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 disabled:opacity-50 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-300 flex items-center justify-center"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Processing...
                  </>
                ) : (
                  <>
                    <BarChart3 className="h-5 w-5 mr-2" />
                    Generate Prediction
                  </>
                )}
              </button>
              
              {prediction !== null && (
                <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-lg p-6 text-center">
                  <div className="text-3xl font-bold text-green-400 mb-2">
                    {selectedModel === 'demand-forecasting' && `${prediction.toFixed(0)} kWh`}
                    {selectedModel === 'energy-optimization' && `${prediction.toFixed(1)}% Efficiency`}
                    {selectedModel === 'location-analysis' && `${prediction.toFixed(1)} Score`}
                    {selectedModel === 'peak-prediction' && `${prediction.toFixed(0)}:00`}
                  </div>
                  <div className="text-gray-300">
                    {selectedModel === 'demand-forecasting' && 'Predicted Energy Demand'}
                    {selectedModel === 'energy-optimization' && 'Optimization Potential'}
                    {selectedModel === 'location-analysis' && 'Location Suitability'}
                    {selectedModel === 'peak-prediction' && 'Peak Usage Time'}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Model Performance Metrics */}
        <div className="mt-12 bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-sm border border-slate-600/30 rounded-xl p-8">
          <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
            <BarChart3 className="h-6 w-6 text-cyan-400 mr-3" />
            Model Performance Comparison
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {models.map((model, index) => (
              <div key={model.id} className="text-center">
                <div className={`w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r ${model.color} flex items-center justify-center`}>
                  <model.icon className="h-8 w-8 text-white" />
                </div>
                <h4 className="text-white font-semibold mb-2">{model.name}</h4>
                <div className="text-2xl font-bold text-cyan-400 mb-1">{model.accuracy}%</div>
                <div className="text-sm text-gray-400">Accuracy Score</div>
                <div className="mt-3 bg-slate-700 rounded-full h-2">
                  <div 
                    className={`bg-gradient-to-r ${model.color} h-2 rounded-full transition-all duration-1000`}
                    style={{ width: `${model.accuracy}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default MLModels;