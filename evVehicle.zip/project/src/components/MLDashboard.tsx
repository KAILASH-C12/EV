import React, { useState, useEffect } from 'react';
import { Brain, TrendingUp, Zap, MapPin, Clock, Activity, Target, AlertTriangle, CheckCircle, Cpu } from 'lucide-react';

interface StationEfficiency {
  id: string;
  name: string;
  efficiency: number;
  trend: 'up' | 'down' | 'stable';
  prediction: number;
  status: 'optimal' | 'warning' | 'critical';
  utilization: number;
  energyOutput: number;
  maintenanceScore: number;
}

interface MLPrediction {
  type: 'demand' | 'efficiency' | 'maintenance' | 'revenue';
  value: number;
  confidence: number;
  trend: number;
  timeframe: string;
}

const MLDashboard: React.FC = () => {
  const [stations, setStations] = useState<StationEfficiency[]>([]);
  const [predictions, setPredictions] = useState<MLPrediction[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedTimeframe, setSelectedTimeframe] = useState('24h');

  useEffect(() => {
    // Simulate real-time ML analysis
    const generateStationData = () => {
      const stationData: StationEfficiency[] = Array.from({ length: 12 }, (_, i) => ({
        id: `station_${i + 1}`,
        name: `Station ${String.fromCharCode(65 + i)}`,
        efficiency: Math.random() * 40 + 60, // 60-100%
        trend: ['up', 'down', 'stable'][Math.floor(Math.random() * 3)] as 'up' | 'down' | 'stable',
        prediction: Math.random() * 20 + 80, // 80-100%
        status: Math.random() > 0.7 ? 'warning' : Math.random() > 0.9 ? 'critical' : 'optimal',
        utilization: Math.random() * 40 + 40, // 40-80%
        energyOutput: Math.random() * 500 + 200, // 200-700 kWh
        maintenanceScore: Math.random() * 30 + 70 // 70-100
      }));
      setStations(stationData);
    };

    const generatePredictions = () => {
      const predictionData: MLPrediction[] = [
        {
          type: 'demand',
          value: Math.random() * 200 + 300,
          confidence: Math.random() * 20 + 80,
          trend: Math.random() * 30 - 15,
          timeframe: selectedTimeframe
        },
        {
          type: 'efficiency',
          value: Math.random() * 15 + 85,
          confidence: Math.random() * 15 + 85,
          trend: Math.random() * 10 - 5,
          timeframe: selectedTimeframe
        },
        {
          type: 'maintenance',
          value: Math.random() * 5 + 2,
          confidence: Math.random() * 20 + 75,
          trend: Math.random() * 2 - 1,
          timeframe: selectedTimeframe
        },
        {
          type: 'revenue',
          value: Math.random() * 5000 + 15000,
          confidence: Math.random() * 25 + 75,
          trend: Math.random() * 1000 - 500,
          timeframe: selectedTimeframe
        }
      ];
      setPredictions(predictionData);
    };

    generateStationData();
    generatePredictions();

    const interval = setInterval(() => {
      generateStationData();
      generatePredictions();
    }, 5000);

    return () => clearInterval(interval);
  }, [selectedTimeframe]);

  const runMLAnalysis = async () => {
    setIsAnalyzing(true);
    await new Promise(resolve => setTimeout(resolve, 3000));
    setIsAnalyzing(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'optimal': return 'from-green-500 to-emerald-400';
      case 'warning': return 'from-yellow-500 to-orange-400';
      case 'critical': return 'from-red-500 to-pink-400';
      default: return 'from-gray-500 to-gray-400';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-400" />;
      case 'down': return <TrendingUp className="h-4 w-4 text-red-400 rotate-180" />;
      default: return <Activity className="h-4 w-4 text-yellow-400" />;
    }
  };

  return (
    <section className="bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 py-16">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <div className="bg-gradient-to-r from-cyan-400 to-purple-500 p-3 rounded-full mr-4">
              <Brain className="h-8 w-8 text-white" />
            </div>
            <h2 className="text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              AI-Powered Station Intelligence
            </h2>
          </div>
          <p className="text-gray-300 text-xl max-w-3xl mx-auto">
            Real-time machine learning analysis providing predictive insights, efficiency optimization, 
            and intelligent recommendations for your charging network
          </p>
        </div>

        {/* Control Panel */}
        <div className="bg-gradient-to-r from-slate-800/80 to-slate-700/80 backdrop-blur-xl border border-slate-600/50 rounded-2xl p-6 mb-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center space-x-4">
              <select
                value={selectedTimeframe}
                onChange={(e) => setSelectedTimeframe(e.target.value)}
                className="bg-slate-700/80 border border-slate-600 rounded-xl px-4 py-2 text-white focus:ring-2 focus:ring-cyan-400"
              >
                <option value="1h">Next Hour</option>
                <option value="24h">Next 24 Hours</option>
                <option value="7d">Next 7 Days</option>
                <option value="30d">Next 30 Days</option>
              </select>
              <div className="flex items-center space-x-2 text-gray-300">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-sm">Live Analysis Active</span>
              </div>
            </div>
            <button
              onClick={runMLAnalysis}
              disabled={isAnalyzing}
              className="bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-600 hover:to-purple-700 disabled:opacity-50 text-white font-semibold px-6 py-3 rounded-xl transition-all duration-300 flex items-center"
            >
              {isAnalyzing ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Analyzing...
                </>
              ) : (
                <>
                  <Cpu className="h-5 w-5 mr-2" />
                  Run Deep Analysis
                </>
              )}
            </button>
          </div>
        </div>

        {/* ML Predictions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {predictions.map((prediction, index) => {
            const colors = [
              'from-blue-500 to-cyan-400',
              'from-purple-500 to-pink-400',
              'from-green-500 to-emerald-400',
              'from-orange-500 to-red-400'
            ];
            const icons = [Zap, Target, AlertTriangle, TrendingUp];
            const IconComponent = icons[index];

            return (
              <div key={prediction.type} className={`bg-gradient-to-br ${colors[index]}/20 backdrop-blur-sm border border-gray-600/30 rounded-2xl p-6 hover:scale-105 transition-all duration-300`}>
                <div className="flex items-center justify-between mb-4">
                  <IconComponent className={`h-8 w-8 bg-gradient-to-r ${colors[index]} bg-clip-text text-transparent`} />
                  <div className="text-right">
                    <div className="text-xs text-gray-400 uppercase tracking-wide">
                      {prediction.timeframe}
                    </div>
                    <div className="text-xs text-gray-400">
                      {prediction.confidence.toFixed(1)}% confidence
                    </div>
                  </div>
                </div>
                <div className="mb-2">
                  <div className="text-2xl font-bold text-white mb-1">
                    {prediction.type === 'demand' && `${prediction.value.toFixed(0)} kWh`}
                    {prediction.type === 'efficiency' && `${prediction.value.toFixed(1)}%`}
                    {prediction.type === 'maintenance' && `${prediction.value.toFixed(1)} days`}
                    {prediction.type === 'revenue' && `$${prediction.value.toLocaleString()}`}
                  </div>
                  <div className={`text-sm flex items-center ${prediction.trend > 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {prediction.trend > 0 ? '↗' : '↘'} {Math.abs(prediction.trend).toFixed(1)}
                    {prediction.type === 'efficiency' && '%'}
                    {prediction.type === 'revenue' && '$'}
                  </div>
                </div>
                <h3 className="text-white font-semibold capitalize">
                  {prediction.type} Forecast
                </h3>
              </div>
            );
          })}
        </div>

        {/* Station Efficiency Matrix */}
        <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8 mb-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-3xl font-bold text-white flex items-center">
              <MapPin className="h-8 w-8 text-cyan-400 mr-3" />
              Station Performance Matrix
            </h3>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                <span className="text-sm text-gray-300">Optimal</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                <span className="text-sm text-gray-300">Warning</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                <span className="text-sm text-gray-300">Critical</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {stations.map((station) => (
              <div key={station.id} className={`bg-gradient-to-br ${getStatusColor(station.status)}/10 border border-gray-600/30 rounded-xl p-4 hover:scale-105 transition-all duration-300`}>
                <div className="flex items-center justify-between mb-3">
                  <h4 className="text-white font-semibold">{station.name}</h4>
                  <div className="flex items-center space-x-1">
                    {getTrendIcon(station.trend)}
                    {station.status === 'optimal' && <CheckCircle className="h-4 w-4 text-green-400" />}
                    {station.status === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-400" />}
                    {station.status === 'critical' && <AlertTriangle className="h-4 w-4 text-red-400" />}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400 text-sm">Efficiency</span>
                    <span className="text-white font-semibold">{station.efficiency.toFixed(1)}%</span>
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-2">
                    <div 
                      className={`bg-gradient-to-r ${getStatusColor(station.status)} h-2 rounded-full transition-all duration-1000`}
                      style={{ width: `${station.efficiency}%` }}
                    ></div>
                  </div>
                  
                  <div className="flex justify-between items-center text-xs text-gray-400 mt-3">
                    <span>Utilization: {station.utilization.toFixed(0)}%</span>
                    <span>Output: {station.energyOutput.toFixed(0)} kWh</span>
                  </div>
                  
                  <div className="bg-slate-700/50 rounded-lg p-2 mt-2">
                    <div className="text-xs text-gray-400 mb-1">ML Prediction</div>
                    <div className="text-cyan-400 font-semibold">{station.prediction.toFixed(1)}% efficiency</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Advanced Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Real-time Trends */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Activity className="h-6 w-6 text-purple-400 mr-3" />
              Real-time Efficiency Trends
            </h3>
            <div className="h-64 flex items-end justify-between space-x-1">
              {Array.from({ length: 24 }, (_, i) => {
                const height = Math.random() * 200 + 50;
                const efficiency = (height / 250) * 100;
                return (
                  <div key={i} className="flex flex-col items-center group">
                    <div 
                      className="bg-gradient-to-t from-cyan-500 via-purple-500 to-pink-400 rounded-t-lg w-3 transition-all hover:scale-110 relative"
                      style={{ height: `${height}px` }}
                    >
                      <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-slate-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
                        {efficiency.toFixed(0)}%
                      </div>
                    </div>
                    <span className="text-xs text-gray-400 mt-2">
                      {i}h
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ML Insights */}
          <div className="bg-gradient-to-br from-slate-800/50 to-slate-700/50 backdrop-blur-xl border border-slate-600/30 rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-white mb-6 flex items-center">
              <Brain className="h-6 w-6 text-cyan-400 mr-3" />
              AI Insights & Recommendations
            </h3>
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-green-500/20 to-emerald-500/20 border border-green-500/30 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <CheckCircle className="h-5 w-5 text-green-400 mr-2" />
                  <span className="text-green-300 font-semibold">Optimization Opportunity</span>
                </div>
                <p className="text-gray-300 text-sm">
                  Station C shows 23% efficiency improvement potential through load balancing optimization.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border border-yellow-500/30 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <AlertTriangle className="h-5 w-5 text-yellow-400 mr-2" />
                  <span className="text-yellow-300 font-semibold">Maintenance Alert</span>
                </div>
                <p className="text-gray-300 text-sm">
                  Station H requires preventive maintenance within 3.2 days based on performance degradation patterns.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-blue-500/20 to-cyan-500/20 border border-blue-500/30 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <TrendingUp className="h-5 w-5 text-cyan-400 mr-2" />
                  <span className="text-cyan-300 font-semibold">Demand Forecast</span>
                </div>
                <p className="text-gray-300 text-sm">
                  Peak demand expected at 6 PM with 340% increase. Recommend pre-charging energy storage systems.
                </p>
              </div>
              
              <div className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <Target className="h-5 w-5 text-purple-400 mr-2" />
                  <span className="text-purple-300 font-semibold">Revenue Optimization</span>
                </div>
                <p className="text-gray-300 text-sm">
                  Dynamic pricing model suggests 15% rate increase during peak hours could boost revenue by $2,340.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default MLDashboard;