import React from 'react';
import { Zap, BarChart3, Brain, Database } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-blue-900 via-purple-900 to-indigo-900 text-white shadow-2xl">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="bg-gradient-to-r from-cyan-400 to-blue-500 p-2 rounded-lg">
              <Zap className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-cyan-300 to-blue-300 bg-clip-text text-transparent">
                EV Charge Analytics
              </h1>
              <p className="text-blue-200 text-sm">Advanced ML-Powered Insights</p>
            </div>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#dashboard" className="flex items-center space-x-2 hover:text-cyan-300 transition-colors">
              <BarChart3 className="h-4 w-4" />
              <span>Dashboard</span>
            </a>
            <a href="#analytics" className="flex items-center space-x-2 hover:text-cyan-300 transition-colors">
              <Brain className="h-4 w-4" />
              <span>ML Models</span>
            </a>
            <a href="#data" className="flex items-center space-x-2 hover:text-cyan-300 transition-colors">
              <Database className="h-4 w-4" />
              <span>Data Explorer</span>
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;